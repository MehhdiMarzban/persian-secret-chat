const express = require("express");
const {createServer} = require("http");
const {Server} = require("socket.io");
const cors = require("cors");


const app = express();
app.use(cors());

const httpServer = createServer(app);
const io = new Server(httpServer, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

io.on("connection", (socket) => {
    console.log("someone connected! ", socket.id);

    socket.on("disconnect", () => {
        console.log("someone disconnected ! ", socket.id);
    });

    socket.on("join_room", (data) => {
        socket.join(data.chatCode);
    });

    socket.on("send_message", (data) => {
        socket.to(data.chatCode).emit("recieve_message", data);
    });
});


httpServer.listen(3030, () => {
    console.log("server run it on port 3030");
})