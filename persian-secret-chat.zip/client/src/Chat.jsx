import Message from "./Message";
import {useState, useEffect} from "react";
const Chat = ({ socket, username, chatCode }) => {
    const [textState, setTextState] = useState("");
    const [messagesState, setMessageState] = useState([]);
    useEffect(() => {
        socket.on("recieve_message", (data) => {
            setMessageState((message) => [...message, data]);
        });
    }, [socket]);

    const sendMessage = async () => {
        const data = {
            username,
            text: textState,
            chatCode
        }
        await socket.emit("send_message", data);
        setMessageState((message) => [...message, data]);
        setTextState("");
    }
    return (
        <>
            <div className="d-flex flex-column bg-white rounded py-5 px-1 w-100 justify-content-center">
                <div className="text-center">
                    <h4>اتاق چت خصوصی</h4>
                    <hr />
                </div>
                <div className="p-2 rounded bg-light" style={{height: "400px", overflowY: "scroll"}}>
                    {messagesState.map((message, index) => {
                        return <Message username={message.username} text={message.text} status={message.username === username ? "you" : "someone"} key={index}/>
                    })}
                </div>
                <div className="my-2">
                    <div className="input-group mb-3">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="پیام خود را وارد کنید ..."
                            aria-label="Recipient's username"
                            aria-describedby="button-addon2"
                            dir="rtl"
                            value={textState}
                            onChange={(e) => {setTextState(e.target.value)}}
                            onKeyPress={(e) => {if(e.key === "Enter") sendMessage();}}
                        />
                        <div className="input-group-append">
                            <button
                                className="btn btn-md btn-default m-0 px-3 py-2 z-depth-0 waves-effect"
                                type="button"
                                id="button-addon2"
                                onClick={sendMessage}
                                >
                                <i className="fa fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Chat;
