const Message = ({ status, text, username }) => {
    return (
        <>
            {status === "you" ? (
                <div className="d-flex flex-row animated fadeIn">
                    <div className="d-flex mr-auto mb-1">
                        <small className="text-white bg-dark p-1 m-1 rounded">{username}</small>
                        <div className="bg-primary text-white rounded text-center px-5">{text}</div>
                    </div>
                </div>
            ) : (
                <div className="d-flex flex-row animated fadeIn">
                    <div className="d-flex ml-auto mb-1">
                        <div className="bg-success text-white text-center px-5 py-1 rounded">
                            {text}
                        </div>
                        <small className="text-white bg-dark p-1 m-1 rounded">{username}</small>
                    </div>
                </div>
            )}
        </>
    );
};

export default Message;
