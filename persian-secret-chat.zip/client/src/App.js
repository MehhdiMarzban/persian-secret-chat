import io from "socket.io-client";
import Chat from "./Chat";
import { useState } from "react";
const socket = io.connect("https://mehdisocket.iran.liara.run");
const App = () => {
    const [showChatState, setShowChatState] = useState(false);
    const [usernameState, setUsernameState] = useState("");
    const [chatCodeState, setChatCodeState] = useState("");
    const validateAndStartChat = () => {
        if(usernameState.length > 0 && chatCodeState.length > 0){
            setShowChatState(true);
            const data = {
                username: usernameState,
                chatCode: chatCodeState
            }
            socket.emit("join_room", data);
        }
    };
    return (
        <>
            <div
                style={{ height: "100vh" }}
                className="py-5 px-2 teal accent-4 d-flex justify-content-center align-items-center">
                {!showChatState ? (
                    <div className="w-100 bg-white p-3 rounded">
                        <h5 className="text-center">اطلاعات خود را وارد کنید</h5>
                        <div className="md-form input-with-post-icon">
                            <input
                                type="text"
                                id="suffixInside"
                                className="form-control text-center"
                                onChange={(e) => {
                                    setUsernameState(e.target.value);
                                }}
                            />
                            <label for="suffixInside">نام کاربری</label>
                        </div>
                        <div className="md-form input-with-post-icon">
                            <input
                                type="text"
                                id="suffixInside"
                                className="form-control text-center"
                                onChange={(e) => {
                                    setChatCodeState(e.target.value);
                                }}
                            />
                            <label for="suffixInside">رمز چت</label>
                        </div>
                        <button
                            className="btn pjs-btn-primary text-center d-block mx-auto w-50"
                            onClick={validateAndStartChat}>
                            ورود
                        </button>
                    </div>
                ) : (
                    <Chat socket={socket} username={usernameState} chatCode={chatCodeState}/>
                )}
            </div>
        </>
    );
};

export default App;
